package shapes;

public class ScaleneTriangle extends Triangle{
    public ScaleneTriangle(double sideA, double sideB, double sideC){
        super(sideA, sideB, sideC);
    }
}
