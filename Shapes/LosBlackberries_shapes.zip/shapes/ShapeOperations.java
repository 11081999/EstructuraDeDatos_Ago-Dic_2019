package shapes;

public interface ShapeOperations {
	
	public abstract double calculateArea();
	public abstract double calculatePerimeter();
	
}