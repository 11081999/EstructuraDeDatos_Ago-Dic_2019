package shapes;

public abstract class Shape implements ShapeOperations{
	
	public String name;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}


}